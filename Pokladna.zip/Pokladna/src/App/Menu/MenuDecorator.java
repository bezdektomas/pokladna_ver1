package App.Menu;

import App.Produkt;

public abstract class MenuDecorator extends Produkt {
    @Override
    public abstract int cena();
}
