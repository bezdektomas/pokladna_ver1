package App.Burgery;

import App.Produkt;

public abstract class BurgerDecorator extends Produkt {
    @Override
    public abstract int cena();
}
