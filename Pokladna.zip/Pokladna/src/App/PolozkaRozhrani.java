package App;

public interface PolozkaRozhrani {
    String nazev();
    int cena();
}
