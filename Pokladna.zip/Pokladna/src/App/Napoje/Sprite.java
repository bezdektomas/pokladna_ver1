package App.Napoje;

import App.Produkt;

public class Sprite extends Produkt {
    public Sprite(){
        nazev = "Sprite";
     }
    
     @Override
     public int cena() {
         return 39;
     }
}
