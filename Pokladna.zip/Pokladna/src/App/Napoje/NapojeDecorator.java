package App.Napoje;

import App.Produkt;

public abstract class NapojeDecorator extends Produkt {
    @Override
    public abstract int cena();
}
