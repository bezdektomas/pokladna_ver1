package App.Ostatni;

import App.Produkt;

public abstract class OstatniDecorator extends Produkt {
    @Override
    public abstract int cena();
}
