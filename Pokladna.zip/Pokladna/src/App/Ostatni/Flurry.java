package App.Ostatni;

import App.Produkt;

public class Flurry extends Produkt {
    public Flurry(){
        nazev = "McFlurry";
     }
    
     @Override
     public int cena() {
         return 55;
     }
}
